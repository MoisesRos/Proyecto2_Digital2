/* USER CODE BEGIN Header */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include "ili9341.h"
#include "Bitmaps.h"
#include <string.h>
#include <stdbool.h>
#include "pgmspace.h"
#include <stdlib.h>

#ifndef MAX
  #define MAX(a,b) (((a) > (b)) ? (a) : (b))
#endif
#ifndef MIN
  #define MIN(a,b) (((a) < (b)) ? (a) : (b))
#endif
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
extern const uint8_t smallFont[1140];
extern const uint16_t bigFont[1520];
extern uint8_t title[];
extern uint8_t menu[];
extern uint8_t nube[];  // tu nube de 140×70
static volatile bool inWinnerScreen = false;

//extern uint8_t corazon1[];
//extern uint8_t corazon2[];
#define WIN_WIDTH  320   // ajusta si tu bmp es de otra resolución
#define WIN_HEIGHT 240


#define COLOR_KEY 0x0000
#define SCREEN_WIDTH   320
#define SCREEN_HEIGHT  240
#define TITLE_WIDTH    100
#define TITLE_HEIGHT   70
#define FINAL_TITLE_Y  ((SCREEN_HEIGHT - TITLE_HEIGHT)/2)
#define TITLE_X        110
#define COLOR_KEY      0x0000
#define ANIMATION_DELAY_MS  1
#define STEP               10
#define TEXT_X        60
#define TEXT_Y        180
#define BLINK_DELAY_MS 500
#define GAME_BG_COLOR  0x005D
#define CLOUD_WIDTH   140
#define CLOUD_HEIGHT   70
#define CHAR_W         40
#define CHAR_H         40
#define MOVE_STEP       4   // píxeles por movimiento

#define COLLISION_MARGIN_X  4
#define COLLISION_MARGIN_Y  4

#define MUSIC_WINNER '3'

typedef enum { STATE_MENU, STATE_PLAY, STATE_PAUSE, STATE_WINNER } GameState;
static volatile GameState gameState = STATE_MENU;
/* UART parsing --------------------------------------------------------------*/

/* buffers */
static uint8_t rxChar2, rxChar5; //static char uartCmd[2];
/* para parsear comandos de 2 bytes en UART5 */

static uint8_t stateCode = 0;/* Posición y estado del personaje ------------------------------------------*/
static int  charX, charY;
static int  charIdx, charFlip;  // columna (0 o 1), flip (0/1)
static int  char2X,   char2Y;
static int  char2Idx, char2Flip;
// Guarda si el último prefijo fue '1' o '2'

// Buffers de respaldo
#define TITLE_BG_BUFFER_SIZE  (TITLE_WIDTH*TITLE_HEIGHT*2)
static uint8_t titleBgBuffer[TITLE_BG_BUFFER_SIZE];
void LCD_Print_Transparent(char *text, int x, int y, int fontSize, int color);


/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;

UART_HandleTypeDef huart5;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
// --- Obstáculos ---
typedef struct {
    int16_t x, y;  // Cambia de uint16_t a int16_t
    uint8_t type;
    bool active;
} Obstacle;

#define MAX_OBS      3
static Obstacle obs[MAX_OBS];
// Golpes y vidas
static uint8_t hits1, hits2;
static uint8_t lifeIdx1, lifeIdx2;

// Velocidades (pix/frame)
#define SPEED_BIRD   2
#define SPEED_PLANE  4

// Contadores de golpes
static uint8_t hits1 = 0, hits2 = 0;
// Índices de corazon
static uint8_t lifeIdx1 = 0, lifeIdx2 = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_UART5_Init(void);
/* USER CODE BEGIN PFP */
// Prototipos de tus funciones de usuario
void LCD_FillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color);

void RunMainMenu(void);
void AnimateClouds(void);
void ShowPauseMenu(void);
void Restore_Title_Area(int posY);
void Restore_Text_Area(char *text, int x, int y, int fontSize);
void LCD_Sprite_Transparent(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint8_t bitmap[], uint16_t colorKey);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/////////////////////////////////////////////
// Prototipo
void ShowWinner(int player);

// Implementación
void ShowWinner(int player) {
    inWinnerScreen = true;
    LCD_Clear(0x0000);

    char buf[32];
    sprintf(buf, "Gana jugador %d", player);
    int x = (SCREEN_WIDTH - strlen(buf) * fontXSizeBig) / 2;
    LCD_Print_Transparent(buf, x, SCREEN_HEIGHT/2 - fontYSizeBig/2, 2, 0xFFFF);

    // Loop hasta que se presione 'A'
    while (inWinnerScreen) {
        HAL_Delay(10);
    }

    // Vuelve al menú principal
    gameState = STATE_MENU;
    //LCD_Clear(GAME_BG_COLOR);
}
////////////////////////////////////////////

// Genera un número pseudoaleatorio pequeño
//static uint8_t rnd8(void) {
//    static uint32_t lfsr = 0xACE1u;
//    lfsr ^= lfsr << 13;  lfsr ^= lfsr >> 17;  lfsr ^= lfsr << 5;
//    return (uint8_t)(lfsr);
//}

// Inicializa todos inactivos

static void Obs_Init(void) {
    for (int i = 0; i < MAX_OBS; i++) obs[i].active = false;
}

// Intenta generar un nuevo obstáculo con probabilidad ~10%
static void Obs_Spawn(void) {
    // Fuerza la generación de 1 enemigo cada 2 frames (para prueba)
    static uint8_t spawnCounter = 0;
    spawnCounter++;

    if (spawnCounter % 2 == 0) { // Cada 2 frames
        for (int i = 0; i < MAX_OBS; i++) {
            if (!obs[i].active) {
                obs[i].active = true;
                obs[i].type = rand() % 2;
                obs[i].x = rand() % (SCREEN_WIDTH - 50);
                obs[i].y = -40; // Más arriba para que tarde en salir
                break;
            }
        }
    }
}


// Dibuja corazones de vida
static void Draw_Lives(void) {
	// Calcula la columna del bitmap según los golpes recibidos
	    uint8_t idx1 = (hits1 >= 3) ? 2 : hits1;
	    uint8_t idx2 = (hits2 >= 3) ? 2 : hits2;
    // jugador1
	LCD_Sprite(0, 0, 24, 13, corazon1, 3, idx1, 0, 0);
    // jugador2
	LCD_Sprite(SCREEN_WIDTH-24, 0, 24, 13, corazon2, 3, idx2, 0, 0);
}


/* --- Función para dibujar un píxel --- */
void LCD_DrawPixel(uint16_t x, uint16_t y, uint16_t color) {
    HAL_GPIO_WritePin(LCD_CS_GPIO_Port, LCD_CS_Pin, GPIO_PIN_RESET);
    SetWindows(x, y, x, y);
    LCD_DATA(color >> 8);
    LCD_DATA(color);
    HAL_GPIO_WritePin(LCD_CS_GPIO_Port, LCD_CS_Pin, GPIO_PIN_SET);
}

/* --- Función para dibujar un sprite con transparencia --- */
/* Recorre la imagen del sprite (se asume columns=1, index=0, sin flip ni offset) y para cada píxel,
   si el color es distinto de COLOR_TRANSPARENTE lo dibuja; de lo contrario, se omite (dejando el fondo intacto) */
void LCD_Sprite_Transparent(uint16_t x, uint16_t y, uint16_t width, uint16_t height,
                              unsigned char bitmap[], uint16_t colorKey) {
    for (int j = 0; j < height; j++) {
        for (int i = 0; i < width; i++) {
            int idx = (j * width + i) * 2;
            uint16_t color = (bitmap[idx] << 8) | bitmap[idx + 1];
            if (color != colorKey) {
                LCD_DrawPixel(x + i, y + j, color);
            }
        }
    }
}

/* --- Función para imprimir texto sin fondo (transparente) --- */
void LCD_Print_Transparent(char *text, int x, int y, int fontSize, int color) {
    int fontXSize, fontYSize;
    if (fontSize == 1) {
        fontXSize = fontXSizeSmal;
        fontYSize = fontYSizeSmal;
    } else if (fontSize == 2) {
        fontXSize = fontXSizeBig;
        fontYSize = fontYSizeBig;
    } else if (fontSize == 3) {
        fontXSize = fontXSizeNum;
        fontYSize = fontYSizeNum;
    }
    int cLength = strlen(text);
    for (int i = 0; i < cLength; i++) {
        char ch = text[i];
        int charDec = (int) ch;
        for (int row = 0; row < fontYSize; row++) {
            long charData;
            if (fontSize == 1) {
                charData = pgm_read_word_near(smallFont + ((charDec - 32) * fontYSize) + row);
            } else if (fontSize == 2) {
                charData = pgm_read_word_near((const uint16_t*)bigFont + ((charDec - 32) * fontYSize) + row);
            } else {
                charData = 0;
            }
            for (int col = 0; col < fontXSize; col++) {
                if (charData & (1 << (fontXSize - 1 - col))) {
                    LCD_DrawPixel(x + i * fontXSize + col, y + row, color);
                }
            }
        }
    }
}


// Restaura la región donde estaba el título
void Restore_Title_Area(int posY) {
    int effH = TITLE_HEIGHT;
    int y0 = posY;
    if (y0 < 0)      { effH += y0; y0 = 0; }
    if (y0+effH>SCREEN_HEIGHT) effH = SCREEN_HEIGHT - y0;
    for (int i = 0; i < effH; i++) {
        int idx = ((y0 + i)*SCREEN_WIDTH + TITLE_X)*2;
        memcpy(&titleBgBuffer[i*TITLE_WIDTH*2], &menu[idx], TITLE_WIDTH*2);
    }
    LCD_Bitmap(TITLE_X, y0, TITLE_WIDTH, effH, titleBgBuffer);
}

// Restaura la región donde estaba un texto de tamaño fontSize
void Restore_Text_Area(char *text, int x, int y, int fontSize) {
    int fontX = (fontSize==1?fontXSizeSmal:(fontSize==2?fontXSizeBig:fontXSizeNum));
    int fontY = (fontSize==1?fontYSizeSmal:(fontSize==2?fontYSizeBig:fontYSizeNum));
    int w = strlen(text)*fontX;
    static uint8_t buf[320*2];  // suficiente para una línea
    for (int row=0; row<fontY; row++) {
        int idx = ((y+row)*SCREEN_WIDTH + x)*2;
        memcpy(buf, &menu[idx], w*2);
        LCD_Bitmap(x, y+row, w, 1, buf);
    }
}

void RunMainMenu(void) {
    LCD_Bitmap(0,0,SCREEN_WIDTH,SCREEN_HEIGHT,menu);
    int oldY = -TITLE_HEIGHT;
    for (int y=oldY+STEP; y<=FINAL_TITLE_Y && gameState==STATE_MENU; y+=STEP) {
        Restore_Title_Area(oldY);
        LCD_Sprite_Transparent(TITLE_X, y, TITLE_WIDTH, TITLE_HEIGHT, title, COLOR_KEY);
        HAL_Delay(ANIMATION_DELAY_MS);
        oldY = y;
    }
    if (gameState!=STATE_MENU) return;
//    LCD_Sprite_Transparent(TITLE_X, FINAL_TITLE_Y, TITLE_WIDTH, TITLE_HEIGHT, title, COLOR_KEY);

    char msg[] = "PRESIONE A PARA COMENZAR";
    while (gameState==STATE_MENU) {
        LCD_Print_Transparent(msg, TEXT_X, TEXT_Y, 1, 0x0000);
        HAL_Delay(BLINK_DELAY_MS);
        Restore_Text_Area(msg, TEXT_X, TEXT_Y, 1);
        HAL_Delay(BLINK_DELAY_MS);
    }
}

void ShowPauseMenu(void) {
    LCD_Clear(0x0000);
    LCD_Print_Transparent("PAUSA", 100, 60, 2, 0xFFFF);
    LCD_Print_Transparent("Presione A para continuar", 40,100, 1,0xFFFF);
    LCD_Print_Transparent("Presione X para salir",      50,120, 1,0xFFFF);
    while (gameState==STATE_PAUSE) HAL_Delay(100);
    LCD_Clear(GAME_BG_COLOR);
}

//void AnimateClouds(void) {
//    for (int y=0; y<SCREEN_HEIGHT-CLOUD_HEIGHT && gameState==STATE_PLAY; y++) {
//        LCD_Sprite(120, y, CLOUD_WIDTH, CLOUD_HEIGHT, nube,1,0,0,0);
//        HAL_Delay(1);
//    }
//}

//PRUEBAAAAA
// Comprueba si las dos cajas de tamaño CHAR_W×CHAR_H se solapan
//static bool isColliding(int x, int y, int otherX, int otherY) {
//    return !( x + CHAR_W <= otherX   // tu derecha antes de la izquierda del otro
//           || x       >= otherX+CHAR_W  // tu izquierda después de la derecha del otro
//           || y + CHAR_H <= otherY   // tu abajo antes de la parte superior del otro
//           || y       >= otherY+CHAR_H ); // tu arriba después de la parte inferior del otro
//}

void LCD_FillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color) {
    // Selecciona chip
    HAL_GPIO_WritePin(LCD_CS_GPIO_Port, LCD_CS_Pin, GPIO_PIN_RESET);
    // Define la ventana
    SetWindows(x, y, x + w - 1, y + h - 1);
    // Escribe pixeles
    for (uint32_t i = 0; i < (uint32_t)w * h; i++) {
        LCD_DATA(color >> 8);
        LCD_DATA(color & 0xFF);
    }
    // Deselecciona chip
    HAL_GPIO_WritePin(LCD_CS_GPIO_Port, LCD_CS_Pin, GPIO_PIN_SET);
}

// Mueve, dibuja y procesa colisión
static void Obs_UpdateAndDraw(void) {
    Obs_Spawn();

    for (int i = 0; i < MAX_OBS; i++) {
        if (!obs[i].active) continue;

        // Mueve el obstáculo
        obs[i].y += (obs[i].type ? SPEED_PLANE : SPEED_BIRD) * 2; // x2 velocidad

        // DEBUG: Envía posición por UART2
        {
            char msg[50];
            sprintf(msg, "Enemy %d: (%d, %d)\r\n", i, obs[i].x, obs[i].y);
            HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
        }

        uint16_t w = obs[i].type ? 45 : 50;
        uint16_t h = obs[i].type ? 45 : 28;

        // --- Colisión Jugador 1 ---
        if (obs[i].x < charX + CHAR_W &&
            obs[i].x + w > charX &&
            obs[i].y < charY + CHAR_H &&
            obs[i].y + h > charY) {
        	// Borra el sprite en su posición
        	LCD_FillRect(obs[i].x, obs[i].y, w, h, GAME_BG_COLOR);
            obs[i].active = false;
            if (hits1 < 3) {
                hits1++;
                lifeIdx1 = (hits1 >= 3 ? 2 : hits1);
                // envío código de daño '1'
                {
                    uint8_t code1 = '3';
                    HAL_UART_Transmit_IT(&huart5, &code1, 1);
                }
                // DEBUG por UART2
                char msg[50];
                sprintf(msg, "Jugador 1 golpeado! Vidas: %d/3\r\n", hits1);
                HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
            }
            continue;  // Salta dibujar este obstáculo
        }

        // --- Colisión Jugador 2 ---
        if (obs[i].x < char2X + CHAR_W &&
            obs[i].x + w > char2X &&
            obs[i].y < char2Y + CHAR_H &&
            obs[i].y + h > char2Y) {
        	// Borra el sprite en su posición
        	LCD_FillRect(obs[i].x, obs[i].y, w, h, GAME_BG_COLOR);
            obs[i].active = false;
            if (hits2 < 3) {
                hits2++;
                lifeIdx2 = (hits2 >= 3 ? 2 : hits2);
                // envío código de daño '1'
                {
                    uint8_t code1 = '3';
                    HAL_UART_Transmit_IT(&huart5, &code1, 1);
                }
                // DEBUG por UART2
                char msg[50];
                sprintf(msg, "Jugador 2 golpeado! Vidas: %d/3\r\n", hits2);
                HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
            }
            continue;  // Salta dibujar este obstáculo
        }

        // Si llegó hasta aquí, no hubo colisión: dibujamos el obstáculo
        LCD_Sprite(obs[i].x, obs[i].y, w, h,
                   obs[i].type ? avion : pajaro,
                   1, 0, 0, 0);

        // Desactiva solo si está completamente fuera de pantalla
        if (obs[i].y > SCREEN_HEIGHT + h) {
            obs[i].active = false;
        }
    }
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  MX_USART2_UART_Init();
  MX_UART5_Init();
  /* USER CODE BEGIN 2 */
  LCD_Init();
  HAL_UART_Receive_IT(&huart2, &rxChar2, 1);
  HAL_UART_Receive_IT(&huart5,  &rxChar5, 1);
  Obs_Init();
  hits1 = 0;
  hits2 = 0;
  lifeIdx1 = 0;
  lifeIdx2 = 0;
  stateCode = 0;

  srand((unsigned) HAL_GetTick());  // inicializa el RNG
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  while (1) {
	  switch (gameState) {
	  case STATE_MENU:
	      //sonido
		  if (stateCode != '2') {
			  stateCode = '2';
			  HAL_UART_Transmit_IT(&huart5, &stateCode, 1);
			  //HAL_UART_Transmit_IT(&huart2, &stateCode, 1);
		  	  }
	      RunMainMenu();
	      if (gameState == STATE_PLAY) {
	          // reinicia todo
	          Obs_Init();
	          hits1 = hits2 = 0;
	          lifeIdx1 = lifeIdx2 = 0;
	          charX    = 90;//(SCREEN_WIDTH  - CHAR_W)/2;
	          charY    = 160;//(SCREEN_HEIGHT - CHAR_H)/2;
	          charIdx  = charFlip = 0;
	          char2X   = 197;//SCREEN_WIDTH/4;
	          char2Y   = 160;//SCREEN_HEIGHT/4;
	          char2Idx = char2Flip = 0;
	          LCD_Clear(GAME_BG_COLOR);


	      }

	      break;

	  case STATE_PLAY:
		  //sonido
		  if (stateCode != '4') {
			  stateCode = '4';
			  HAL_UART_Transmit_IT(&huart5, &stateCode, 1);
			  // HAL_UART_Transmit_IT(&huart2, &stateCode, 1);
		  	  }
		  //LCD_Bitmap(0,0,SCREEN_WIDTH,SCREEN_HEIGHT, menu); // repinta fondo estático
		  Obs_UpdateAndDraw();
		  LCD_Sprite(charX,  charY,  CHAR_W, CHAR_H, personaje1, 2, charIdx,  charFlip,  0);
		  LCD_Sprite(char2X, char2Y, CHAR_W, CHAR_H, personaje2, 2, char2Idx, char2Flip, 0);
		  Draw_Lives();
		  //FillRect(0, 200, 340, 40,GAME_BG_COLOR);

		  if (hits1 >= 3) {
			  uint8_t winCode = '1';
			  HAL_UART_Transmit(&huart5, &winCode, 1, HAL_MAX_DELAY);
			  gameState = STATE_WINNER; // Cambia a STATE_WINNER
		      ShowWinner(2);
		  }
		  else if (hits2 >= 3) {
			  uint8_t winCode = '1';
			  HAL_UART_Transmit(&huart5, &winCode, 1, HAL_MAX_DELAY);
			  gameState = STATE_WINNER;
		      ShowWinner(1);
		  }
		  HAL_Delay(30);

		  break;

	  	  case STATE_WINNER:
	  		if (stateCode != MUSIC_WINNER) {
	  		                stateCode = MUSIC_WINNER;
	  		                HAL_UART_Transmit_IT(&huart5, &stateCode, 1);
	  		            }
	  		  break;

	  	  case STATE_PAUSE:
             //sonido
	  		 if (stateCode != '0') {
	  			 stateCode = '0';
	  			 HAL_UART_Transmit_IT(&huart5, &stateCode, 1);
	  			 //HAL_UART_Transmit_IT(&huart2, &stateCode, 1);
	  		 	 }
	  		  ShowPauseMenu();

	  		 	 break;
	          }
	      }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 80;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */
  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */
  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */
  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief UART5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART5_Init(void)
{

  /* USER CODE BEGIN UART5_Init 0 */

  /* USER CODE END UART5_Init 0 */

  /* USER CODE BEGIN UART5_Init 1 */

  /* USER CODE END UART5_Init 1 */
  huart5.Instance = UART5;
  huart5.Init.BaudRate = 115200;
  huart5.Init.WordLength = UART_WORDLENGTH_8B;
  huart5.Init.StopBits = UART_STOPBITS_1;
  huart5.Init.Parity = UART_PARITY_NONE;
  huart5.Init.Mode = UART_MODE_TX_RX;
  huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart5.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart5) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART5_Init 2 */

  /* USER CODE END UART5_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */
  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */
  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */
  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LCD_RST_Pin|LCD_D1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin|LCD_D7_Pin
                          |LCD_D0_Pin|LCD_D2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LCD_CS_Pin|LCD_D6_Pin|LCD_D3_Pin|LCD_D5_Pin
                          |LCD_D4_Pin|SD_SS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : LCD_RST_Pin LCD_D1_Pin */
  GPIO_InitStruct.Pin = LCD_RST_Pin|LCD_D1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_RD_Pin LCD_WR_Pin LCD_RS_Pin LCD_D7_Pin
                           LCD_D0_Pin LCD_D2_Pin */
  GPIO_InitStruct.Pin = LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin|LCD_D7_Pin
                          |LCD_D0_Pin|LCD_D2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_CS_Pin LCD_D6_Pin LCD_D3_Pin LCD_D5_Pin
                           LCD_D4_Pin SD_SS_Pin */
  GPIO_InitStruct.Pin = LCD_CS_Pin|LCD_D6_Pin|LCD_D3_Pin|LCD_D5_Pin
                          |LCD_D4_Pin|SD_SS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* ISR de recepción */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    uint8_t c;

    // ===== USART2 (Menú/Pausa) =====
    if (huart->Instance == USART2) {
        c = rxChar2;
        HAL_UART_Receive_IT(&huart2, &rxChar2, 1); // Re-arma interrupción

        // --- Manejo de pantalla de ganador ---
        if (inWinnerScreen) {
            if (c == 'A' || c == 'a') { // Solo requiere 'A' para salir
                inWinnerScreen = false;
                return;
            }
        }

        // Lógica normal de menú/pausa
        if (gameState == STATE_MENU) {
            if (c == 'A' || c == 'a') gameState = STATE_PLAY;
        }
        else if (gameState == STATE_PLAY) {
            if (c == 'A' || c == 'a') gameState = STATE_PAUSE;
        }
        else if (gameState == STATE_PAUSE) {
            if (c == 'A' || c == 'a') gameState = STATE_PLAY;
            else if (c == 'X' || c == 'x') gameState = STATE_MENU;
        }
        return;
    }

    // ===== UART5 (Jugadores/Música) =====
    if (huart->Instance == UART5) {
        c = rxChar5;
        HAL_UART_Receive_IT(&huart5, &rxChar5, 1); // Re-arma interrupción

        // --- Manejo de pantalla de ganador ---
        if (inWinnerScreen) {
            if (c == 'A' || c == 'a') { // Solo requiere 'A' para salir
                inWinnerScreen = false;
                return;
            }
        }

        static uint8_t pref5 = 0;

        // Parseo de prefijo jugador (1 ó 2)
        if (c == '1' || c == '2') {
            pref5 = c;
            return;
        }

        // Si no hay prefijo, interpretamos A/X igual que USART2
        if (c == 'A' || c == 'a') {
            if (gameState == STATE_MENU)      gameState = STATE_PLAY;
            else if (gameState == STATE_PLAY) gameState = STATE_PAUSE;
            else if (gameState == STATE_PAUSE)gameState = STATE_PLAY;
            goto SEND_MUSIC_CODE;
        }
        else if ((c == 'X' || c == 'x') && gameState == STATE_PAUSE) {
            gameState = STATE_MENU;
            goto SEND_MUSIC_CODE;
        }

        // Movimientos SOLO en STATE_PLAY
        if (gameState == STATE_PLAY) {
            // Guardamos golpes antes de mover
            uint8_t old1 = hits1, old2 = hits2;

            // Punteros según jugador
            int *px   = (pref5 == '1' ? &charX  : &char2X);
            int *py   = (pref5 == '1' ? &charY  : &char2Y);
            int *pIdx = (pref5 == '1' ? &charIdx: &char2Idx);
            int *pFlp = (pref5 == '1' ? &charFlip:&char2Flip);
            int otherX = (pref5 == '1' ? char2X   : charX);
            int otherY = (pref5 == '1' ? char2Y   : charY);
            int nx = *px, ny = *py, idx = *pIdx, flip = *pFlp;

            // Aplicar movimiento
            switch (c) {
                case 'U': case 'u':
                    ny = MAX(0, *py - MOVE_STEP); idx = 0; flip = 0; break;
                case 'D': case 'd':
                    ny = MIN(SCREEN_HEIGHT - CHAR_H, *py + MOVE_STEP); idx = 0; flip = 0; break;
                case 'R': case 'r':
                    nx = MIN(SCREEN_WIDTH  - CHAR_W, *px + MOVE_STEP); idx = 1; flip = 0; break;
                case 'L': case 'l':
                    nx = MAX(0, *px - MOVE_STEP); idx = 1; flip = 1; break;
                default:
                    break;
            }
            // Comprobar colisión entre jugadores
            bool collides = !( nx + CHAR_W <= otherX ||
                               nx       >= otherX + CHAR_W ||
                               ny + CHAR_H <= otherY ||
                               ny       >= otherY + CHAR_H );
            if (!collides) {
                *px   = nx;
                *py   = ny;
                *pIdx = idx;
                *pFlp = flip;
            }

            // Si subieron golpes => enviamos '1'
            if ((pref5 == '1' && hits1 > old1) ||
                (pref5 == '2' && hits2 > old2)) {
                uint8_t code1 = '3';
                HAL_UART_Transmit_IT(&huart5, &code1, 1);
            }
        }

    SEND_MUSIC_CODE:
        // Reenviamos código de música según estado
        {
            uint8_t newCode = (gameState == STATE_MENU ?  '2'
                              : gameState == STATE_PLAY ?  '4'
                              : /* PAUSE */               '0');
            if (newCode != stateCode) {
                stateCode = newCode;
                HAL_UART_Transmit_IT(&huart5, &stateCode, 1);
            }
        }

        pref5 = 0;
    }
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
